(function($){
	$(document).ready(function(){
		$('#featured_post_widget').flexslider({
    	animation: "slide",
    	controlNav: false,
    	directionNav: false,
    	animationLoop: true,
    	slideshowSpeed: 3200
  	});
	})
})(jQuery)