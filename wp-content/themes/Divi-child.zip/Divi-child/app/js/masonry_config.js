(function($){

  $(document).ready(function(){
    // init Masonry

    if( $('body').hasClass("gallery-ceremony") || $('body').hasClass("gallery-rehearsal-dinner")  ){
      console.log("masonry start")
      var $grid = $('.grid').masonry({
            itemSelector: '.grid-item',
            percentPosition: true,
            columnWidth: '.grid-sizer'
      });


      $grid.imagesLoaded().progress(function() {
         $grid.masonry('layout')
      });
    }

  })
})(jQuery)
