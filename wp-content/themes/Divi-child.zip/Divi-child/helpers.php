<?php

function pr($e){
	echo "<pre>";
	print_r($e);
	echo "<pre>";

}